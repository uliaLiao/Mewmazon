# project_a8o6n_g2x2b_x8k0h

# Timeline

Week 1 (Nov.6 - Nov.12): Finish the implementation of Customers and Accounts

Week 2 (Nov.13 - Nov.19): Finish the implementation of Sellers, Products, and the delivery process

Week 3 (Nov.20 - Nov.25): Finish the implementation of Staffs

# Task Breakdown

Jiaying Liao: frontend and GUI design

Zhonghao(Richard) Yang: frontend and backend 

Ding Ma: backend

# How to use:
https://www.students.cs.ubc.ca/~rzhyang/mewmazon/src/php

please note that to initialize the database and populate the database, please go to https://www.students.cs.ubc.ca/~rzhyang/mewmazon/src/php/admin.php
click reset and click insert
